import React, { Fragment } from "react";

const GoPro = () => {
    return (
    <Fragment>
      <h2> Go Pro Options will be shown here...</h2>
    </Fragment>
    )
};

export default GoPro;
