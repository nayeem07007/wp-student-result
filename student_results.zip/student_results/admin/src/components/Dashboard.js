import React, { Fragment } from 'react';

const Dashboard = () => {
    return (
        <Fragment>
            <h2>This is the Dashboard...</h2>
        </Fragment>
    )
}

export default Dashboard;