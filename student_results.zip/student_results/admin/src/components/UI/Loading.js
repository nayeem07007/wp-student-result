import React from "react";
import { Fragment } from "react";
import Spinner from "./Spinner";

const Loading = () => {
  return (
    <Fragment>
      <Spinner />
    </Fragment>
  );
};

export default Loading;
