import React, { Fragment, useState, useEffect } from "react";
import classes from "./ShowStudentRes.module.css";

const ShowStudentRes = () => {
  console.log("hey... from react....");
  return (
    <Fragment>
      <div>
        hello from react.......... .. . . . .. . . . .. . . . .. . . .. . . .
        .rbjwrbkfhqwebkfbqwkfe ...
      </div>
      {/* <form>
        <div class='form-group row'>
            <label for='exam' class='col-sm-3 col-form-label text-left'>Examination </label>
            <div class='col-sm-9'>
            <input type='text' class='form-control' id='exam' placeholder='examination'>
            </div>
        </div>
        <div class='form-group row'>
            <label for='session' class='col-sm-3 col-form-label text-left'>Session </label>
            <div class='col-sm-9'>
            <input type='text' class='form-control' id='session' placeholder='session'>
            </div>
        </div>
        <div class='form-group row'>
            <label for='semester' class='col-sm-3 col-form-label text-left'>Semester </label>
            <div class='col-sm-9'>
            <input type='text' class='form-control' id='semester' placeholder='semester'>
            </div>
        </div>
        <div class='form-group row'>
            <label for='class' class='col-sm-3 col-form-label text-left'>Class </label>
            <div class='col-sm-9'>
            <input type='text' class='form-control' id='class' placeholder='class'>
            </div>
        </div>
        <div class='form-group row'>
            <label for='roll' class='col-sm-3 col-form-label text-left'>Roll </label>
            <div class='col-sm-9'>
            <input type='text' class='form-control' id='roll' placeholder='roll'>
            </div>
        </div>
        <div class='form-group row'>
            <div class='col-sm-10'>
            <button type='submit' class='btn btn-warning'>Reset</button>
            <button type='submit' class='btn btn-primary'>Search</button>
            </div>
        </div>
      </form> */}
    </Fragment>
  );
};

export default ShowStudentRes;
